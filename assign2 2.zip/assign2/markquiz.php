<!DOCTYPE html>
<html lang="en">
    <?php 
        include("header.inc"); 
        include("menu.inc");
    ?>
    <body> 
        <h1 id="quiz_results">Quiz Results</h1><hr>
        <?php
            //!sanitise data
            function sanitise_input($data){
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            if((isset($_POST["firstname"])) && (isset($_POST["lastname"])) && (isset($_POST["studentid"]))){    
                $firstname = sanitise_input($_POST["firstname"]);
                $lastname = sanitise_input($_POST["lastname"]);
                $studentid = sanitise_input($_POST["studentid"]);
            }
            else{ //to bring back to quiz.php if we try to access this page directly
                header("location: quiz.php");
                exit();
            }
            $err_msg=""; //declaring err_msg
            //!first name
            if($firstname == ""){
                $err_msg .= "<p class='recorded'>Please enter first name.</p>";
            }
            else if(!preg_match("/^[a-zA-Z]+$/", $firstname)){
                $err_msg .= "<p class='recorded'>First name can only contain letters.</p>";
            }

            //!last name
            if($lastname == ""){
                $err_msg .= "<p class='recorded'>Please enter last name.</p>";
            }
            else if(!preg_match("/^[a-zA-Z]+$/", $lastname)){
                $err_msg .= "<p class='recorded'>Last name can only contain letters.</p>";
            }
            //!student ID
            /*if($studentid = ""){
                $err_msg .= "<p class='recorded'>Please enter a student ID.</p>";
            }
            else if(!preg_match("/^[0-9]{7,10}$/", $studentid)){
                $err_msg .= "<p class='recorded'>Student ID can only be 7-10 digits long.</p>";
            }*/
            //!diplay error message if there's any
            if($err_msg != ""){
                echo $err_msg;
                echo "<br><a href='quiz.php' id='return_quiz'>Click here</a>";
                echo "<p id='return'>to go back to the quiz page.</p>";
                exit();
            }

            $score = 0;
            //*question 1
            if(isset($_POST["question1"]))
            {
                $input = $_POST["question1"];
                $answer = "answer1_q1";
                if($input == $answer)
                {
                    $score += 1;
                }
            }
            //*question 2
            if(isset($_POST["answer1_q2"]) && isset($_POST["answer3_q2"]) && isset($_POST["answer4_q2"]) && !isset($_POST["answer2_q2"]))
            {
                $score += 1;
            }
            //*question 3
            if(isset($_POST["question3"]))
            {
                $option = $_POST["question3"];
                if($option == "Karlheinz_Brandenburg")
                {
                    $score += 1;
                }
            }
            //*question 4
            if(isset($_POST["question4"]))
            {
                $input = trim($_POST["question4"]); //!to prevent cheating
                $answer1 = "Fraunhofer Society"; //todo: add more ways of spelling later
                $answer2 = "fraunhofer society";
                $answer3 = "Fraunhofer society";
                if($input == $answer1)
                {
                    $score += 1;
                }
                if($input == $answer2)
                {
                    $score += 1;
                }
                if($input == $answer3)
                {
                    $score += 1;
                }
            }
            //*question 5
            if(isset($_POST["question5"]))
            {
                $input = $_POST["question5"];
                $answer = 1990;
                if($input == $answer)
                {
                    $score += 1;
                }
            }
            //!login to the database if everything is valid
            require_once("settings.php");
            $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

            if(!$conn){
                die("<p>Database connection failure</p>");
            }
            else{ //attemptnum DEFAULT 1,
                $query = "CREATE TABLE IF NOT EXISTS attempts (
                    attemptid INT AUTO_INCREMENT PRIMARY KEY,
                    firstname VARCHAR(30) NOT NULL,  
                    lastname VARCHAR(30) NOT NULL,
                    studentid INT NOT NULL,
                    attemptnum INT NOT NULL,
                    score FLOAT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
                $result = @mysqli_query($conn, $query);
                if(!$result){
                    die("<p class=\"wrong\"> Something is wrong with $query.</p>");
                }
                else{
                    $skip = false; //skip prompt to go back
                    $attemptnum = 1;
                    $query = "SELECT attemptnum FROM attempts WHERE studentid = '$studentid'";
                    $checkid = @mysqli_query($conn, $query);
                    if(mysqli_num_rows($checkid) > 0){ //check number in attemptnum
                        $row = mysqli_fetch_assoc($checkid);
                        $attemptnum = $row['attemptnum'] + 1;
                    }
                    if($attemptnum == 2){
                        echo "<p>You've ran out of attempts.</p><br>";
                        $skip = true;
                        //exit();
                    }
                    if($attemptnum > 2){
                        exit();
                    }
                    $insert_query = "INSERT INTO attempts (attemptid, firstname, lastname, studentid, attemptnum, score, timestamp)
                                                    VALUE (NULL, '$firstname', '$lastname', '$studentid', '$attemptnum', '$score', NULL)";
                    $insert_result  = @mysqli_query($conn, $insert_query);
                    
                    if($skip == false){
                        if($insert_result){
                            echo "<p class='recorded'>Your attempt has been successfully recorded.</p>";
                            echo "<br><a href='quiz.php' id='return_quiz'>Click here</a>";
                            echo "<p id='return'>to have another attempt at the quiz.</p>";
                        }
                        else{
                            echo "<p class='recorded'>Your attempt was recorded unsuccessfully.</p>";
                            exit();
                        }
                    }
                    //!to show the last inputted attempt
                    $query = "SELECT * FROM attempts ORDER BY attemptid DESC LIMIT 1";
                    //reference: https://www.youtube.com/watch?v=3MtrbX8LFTA
                    $show_result = @mysqli_query($conn, $query);
                    if(!$show_result){
                        echo "<p>Something is wrong with ", $show_result,"</p>";
                    }
                    else{
                        if(mysqli_num_rows($show_result) > 0){
                            echo "<table border=\"2\">\n";
                            echo "<tr>\n"
                            ."<th scope=\"col\">Attempt ID</th>\n"
                            ."<th scope=\"col\">Data and Time</th>\n"
                            ."<th scope=\"col\">Student ID</th>\n"
                            ."<th scope=\"col\">First Name</th>\n"
                            ."<th scope=\"col\">Last Name</th>\n"
                            ."<th scope=\"col\">Attempt Number</th>\n"
                            ."<th scope=\"col\">Score</th>\n"
                            ."</tr>";
                            while($row = mysqli_fetch_assoc($show_result)){
                                echo "<tr>\n";
                                echo "<td>",$row["attemptid"],"</td>\n";
                                echo "<td>",$row["timestamp"],"</td>\n";
                                echo "<td>",$row["studentid"],"</td>\n";
                                echo "<td>",$row["firstname"],"</td>\n";
                                echo "<td>",$row["lastname"],"</td>\n";
                                echo "<td>",$row["attemptnum"],"</td>\n";
                                echo "<td>",$row["score"],"</td>\n";
                                echo "</tr>\n";
                            }
                            echo "</table>\n";
                            mysqli_free_result($show_result);
                        }
                        else{
                            echo "<p>No details found.</p>";
                        }
                        mysqli_close($conn);
                    }
                }
            }
        ?>
    </body>
    <?php include("footer.inc"); ?>
</html>