<!DOCTYPE html>
<html lang="en">
<?php
        include("header.inc");
        include("menu.inc");
        
?>
<body> 
    <form method = "post" action="validation.php" novalidate="novalidate">
        <div id="username">
            <fieldset>
                <legend for ="username" class="username">username</legend>
                <textarea id="username" name="admin_username" rows="1" cols="40"></textarea>
            </fieldset> 
        </div>

        <div id="password">
            <fieldset>
                <legend for="password" class="password">password</legend>
                <textarea id="password" name="admin_password" rows="1" cols="40""></textarea>
            </fieldset> 
        </div>

        <div id="submitbutton">
            <p>
                <input type="submit" value="SUBMIT">    
            </p>
        </div>
    </form>
</body>
<?php
    include("footer.inc");
?>

</html>