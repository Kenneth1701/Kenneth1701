<!DOCTYPE html>
<html lang="en">
<?php
    include("header.inc");
    include("menu.inc");
?>
<body>
    <?php 
        $username = isset($_POST["admin_username"]);
        $password = isset($_POST["admin_password"]);
        $valid_user = "Admin";
        $valid_pwd = "Swin12345";
        if($username == $valid_user && $password == $valid_pwd) //!USERNAME AND PASSWORD
        {
            include("manage.php");
            exit();
        }
        else
        {
            echo"<p>Invalid Login information</p>";
            exit();
        }
        if($username == "" || $password == "")
        {
            echo"<p id='return_quiz'>Please enter Username and/or Password</p>";
            echo "<br><a href='admin.php' id='return_quiz'>Click Here to Try Again</a>";
            exit();
        }
    ?>
</body>
<?php  include("footer.inc"); ?>
</html>