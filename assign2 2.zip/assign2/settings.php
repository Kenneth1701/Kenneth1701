<?php
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s105217834";
    $pwd = "240905";
    $sql_db = "s105217834_db";
?>