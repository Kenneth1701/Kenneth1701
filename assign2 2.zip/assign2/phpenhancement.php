<!DOCTYPE html>
<html lang="en">
<?php include("header.inc"); ?>
<body>
    <?php include("menu.inc"); ?>
    <h1>PHP Enhancements</h1>
    <?php
    
    ?>
</body>
</html>