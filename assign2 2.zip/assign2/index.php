<!DOCTYPE html>
<html lang="en">
    <?php include("header.inc"); ?>
    <body>
        <?php include("menu.inc"); ?>
        <div>
            <div id="intro">
                <!--brief intro section-->
                <h1>MP3: A New Era for Audio</h1>
                <p>From phonographs to the walkman, comes a format that revolutionized the audio industry.</p>
            </div>
            <section id="topic">
                <!--for topic.html-->
                <img src="styles/images/mp3_aesthetic.jpeg" width="300" height="300"> <!--move to left-->
                <div class="text">
                    <h2>More on the MP3</h2>
                    <p>The MP3 is the successor of many other audio formats, reaching global recognition. With it, comes the implementation of it in popular devices like the Apple iPod, or in streaming platforms like Spotify. To learn more about it, click here!</p>
                </div>
                <a href="topic.html" target="_blank" class="button"><button>Learn More</button></a>
            </section>
            <section id="quiz">
                <!--for quiz.html-->
                <div class="textquiz">
                    <h2>Refresh Your Knowledge</h2>
                    <p>Caught up on the details? Take the quiz!</p>
                    <a href="quiz.html" target="_blank" class="button"><button>Take a Quiz!</button></a>
                </div>
                <img src="styles/images/new_mp3.jpeg" width="245" height="280">
            </section>

            <section id="enhancement">
                <!--for enhancement.html-->
                <h2>Enhancement</h2>
                <p>You can see what we've done to improve here!</p>
                <a href="enhancement.html" target="_blank" class="button"><button>Things We Improved On</button></a>
            </section>            
            <section id="video">
                <!--YouTube Video (assignment 1)-->
                <h2>Video Explanation</h2><br>
                <p>The link to our short video presentation on the website:</p>
                <a href="https://youtu.be/4XbF3xt-PHs?si=rO8qEdOMc745eXwH" class="enhance_link">Video Demostration</a><br><br>
                <p>Alternatively, you can view the video on the in-built video display right here:</p><br>
                <iframe width="560" height="315" src="https://www.youtube.com/embed/4XbF3xt-PHs?si=Vs4oq91JFGQVcSVw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <!--YouTube Video (assignment 2)-->
                <p>The link to our short video presentation on the server-side PHP scripts:</p>
                <a href="" class="enhance_link">Video Demostration</a><br><br>
                <p>Alternatively, you can view the video on the in-built video display right here:</p><br>
                <iframe> <!--INSERT VIDEO HERE-->
            </section>
        </div>
    </body>
    <?php include("footer.inc"); ?> <!--Rothpitou Poeung-->
</html>

