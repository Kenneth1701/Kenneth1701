<?php
  
   $host = "feenix-mariadb.swin.edu.au";
   $user = "s105217834";
   $pwd = "240905";
   $sql_db = "s105217834_db";
   
   
   $conn = mysqli_connect($host, $user, $pwd, $sql_db);
   $value1 = isset($_POST["list"]);

        switch($value1)
        {
            case "case1":
                echo "<p>Connection successful</p>";
                $query = "SELECT attemptid, fname, lname, studentid, attemptnum, score, time FROM attemps";
                $result = mysqli_query($conn, $query);
                
                if ($result)
                {
                    echo "<p>Select Successful.</p>";
                    if (mysqli_num_rows($result) > 0)
                        {
                            echo "<table>";
                                echo "<tr>";
                                    echo "<th>Attempt ID</th>";
                                    echo "<th>Student ID</th>";
                                    echo "<th>First Name</th>";
                                    echo "<th>Last Name</th>";
                                    echo "<th>Attempt Number</th>";
                                    echo "<th>Score</th>";
                                    echo "<th>Date and Time</th>";
                                echo "</tr>";
                            while ($row = mysqli_fetch_array($result))
                            {
                                echo "<tr>";    
                                    echo "<td>" . $row["attemptid"] . "</td>";
                                    echo "<td>" . $row["studentid"] . "</td>";
                                    echo "<td>" . $row["fname"] . "</td>";
                                    echo "<td>" . $row["lname"] . "</td>";
                                    echo "<td>" . $row["score"] . "</td>";
                                    echo "<td>" . $row["time"] . "</td>";
                                echo "</tr>";
                            }
                            echo "</table>";
                            mysqli_free_result($result);
                        }
                }
                else 
                    echo "<p>Cannot find the records unsuccessful.</p>";
                mysqli_close($conn);
                break;
            case "case2":
               echo "<p>Connection successful</p>";
               $query = "SELECT studentid, fname, lname FROM attempts WHERE score < 3 AND attemptnum = 2 ORDER BY attemptid, attemptnum";
               $result = mysqli_query($conn, $query);
               
               if ($result)
               {
                   echo "<p>Select Successful.</p>";
                   if (mysqli_num_rows($result) > 0)
                   {
                       echo "<table>";
                               echo "<tr>";
                                   echo "<th>Attempt ID</th>";
                                   echo "<th>Student ID</th>";
                                   echo "<th>First Name</th>";
                                   echo "<th>Last Name</th>";
                                   echo "<th>Attempt Number</th>";
                                   echo "<th>Score</th>";
                                   echo "<th>Date and Time</th>";
                               echo "</tr>";
                       while ($row = mysqli_fetch_array($result))
                       {
                           echo "<tr>";    
                                   echo "<td>" . $row["attemptid"] . "</td>";
                                   echo "<td>" . $row["studentid"] . "</td>";
                                   echo "<td>" . $row["fname"] . "</td>";
                                   echo "<td>" . $row["lname"] . "</td>";
                                   echo "<td>" . $row["score"] . "</td>";
                                   echo "<td>" . $row["time"] . "</td>";
                               echo "</tr>";
                   }
                       echo "</table>";
                       mysqli_free_result($result);
               } 
               else 
               {
                   echo "No students found with less than 50% on their second attempt.";
               }
            } 
            else 
                   echo "<p>Cannot find the records unsuccessful.</p>";
               mysqli_close($conn);
                break;
            case "case3":
                echo "<p>Connection successful</p>";
                $query = "SELECT studentid, fname, lname FROM attempts WHERE score = 5 AND attemptnum = 1 ORDER BY attemptid, attemptnum";
                $result = mysqli_query($conn, $query);
                
                if ($result)
                {
                    echo "<p>Select Successful.</p>";
                    if (mysqli_num_rows($result) > 0)
                    {
                        echo "<table>";
                            echo "<tr>";
                                echo "<th>Student ID</th>";
                                echo "<th>First Name</th>";
                                echo "<th>Last Name</th>";
                            echo "</tr>";
                        while ($row = mysqli_fetch_array($result))
                        {
                            echo "<tr>";    
                                echo "<td>" . $row["studentid"] . "</td>";
                                echo "<td>" . $row["fname"] . "</td>";
                                echo "<td>" . $row["lname"] . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                        mysqli_free_result($result);
                    } 
                    else 
                    {
                        echo "No students found with 100% on their first attempt.";
                    }
                } 
                else
                { 
                    echo "<p>Cannot find the records unsuccessful.</p>";
                    mysqli_close($conn);
                }
                break;
            case "case4":
                echo "<p>Connection successful</p>";
                $query = "SELECT studentid, fname, lname FROM attempts WHERE score < 3 AND attemptnum = 2 ORDER BY attemptid, attemptnum";
                $result = mysqli_query($conn, $query);
                
                if ($result)
                {
                    echo "<p>Select Successful.</p>";
                    if (mysqli_num_rows($result) > 0)
                    {
                        echo "<table>";
                        echo "<tr>";
                        echo "<th>Student ID</th>";
                        echo "<th>First Name</th>";
                        echo "<th>Last Name</th>";
                        echo "</tr>";
                        while ($row = mysqli_fetch_array($result))
                        {
                            echo "<tr>";    
                            echo "<td>" . $row["studentid"] . "</td>";
                            echo "<td>" . $row["fname"] . "</td>";
                            echo "<td>" . $row["lname"] . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                        mysqli_free_result($result);
                    } 
                    else 
                    {
                        echo "No students found with less than 50% on their second attempt.";
                    }
                } 
                else 
                {
                    echo "<p>Cannot find the records unsuccessful.</p>";
                    mysqli_close($conn);
                }
                break;
            case "case5":
                echo "<p>Connection successful</p>";
                $query = "DELETE FROM attemmpts WHERE studentid = $studentid";
                $result = mysqli_query($conn, $query);
                
                if ($result)
                {
                    echo "<p>Delete successful. There are ". mysqli_affected_rows($conn). " deleted.</p>";
                }
                else 
                {
                    echo "<p> Delete Unsuccessful.</p>";
                    mysqli_close($conn);
                }
                break;
            case "case6":
                echo "<p>Connection successful</p>";
                $query = "UPDATE attemmpts SET score = '$score' WHERE studentid = $studentid && attemptnum = $attemptnumber";
                $result = mysqli_query($conn, $query);
                
                if ($result)
                {
                    echo "<p>Update successful. There are ". mysqli_affected_rows($conn). " updated.</p>";
                }
                else 
                {
                    echo "<p>Update Unsuccessful.</p>";
                    mysqli_close($conn);
                }
                break;
            
        }
    ?>