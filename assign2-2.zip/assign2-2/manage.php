<!DOCTYPE html>
<html lang="en">
<?php
    include("header.inc");
    include("menu.inc");
?>
<body>
    <h1>Quiz Supervisor</h1>
    <div class = "lists">
    <form method = "post" action="sort.php"></form>
    <ul>
        <li>
            <input type="radio" name = "list" id = "list-all" value = "1" checked = "checked">
            <label for="list1">List all attempts - Sort by field
                <select name="sort-all" id="sort-all">
                    <option value="attempt_id">Attempt ID</option>
                    <option value="time">Date and Time</option>
                    <option value="stuendt_id">student ID</option>
                    <option value="first_name">First Name</option>
                    <option value="last_name">Last Name</option>
                    <option value="attempt_number">Attemt Number</option>
                    <option value="score">Score</option>
                </select>
            </label> 
        </li>
            <input type="radio" name = "list" id = "list-student" value = "2">
            <label for="list2">List all attempts for student with name/number: 
                <input type="text" name = "name_number" size = "15" max-length = "40">
            </label> 
        <li>
            <input type="radio" name = "list" id = "list-100" value = "3" >
            <label for="list3">List all students who got 100% on their first attempt.</label>
        </li>
        <li>
            <input type="radio" name = "list" id = "list-50" value = "4" >
            <label for="list4">List all students who got less than 50% on their last attempt.</label>
        </li>
        <li>
            <input type="radio" name = "list" id = "delete" value = "5" >
            <label for="list5">Delete all students with the student ID: 
                <input type="text" name = "delete" size = "15" max-length = "40">
            </label>
        </li>

        <li>
            <label> 
                <input type="radio" name = "list" id = "change-attempt" value = "6" >
                Change the score for attempt
                <select name="attempts" id="">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                </select>
                For the student with the ID: 
                <input type="text" name = "change-name" size = "15" max-length = "40">
                to the score of 
                <input type="number" name = "supervisor-score" min = "0" max = "10">
            </label>
        </li>
    </ul>

    <input type="submit" value="Enter" class="submit">
    </div>
</body>
</html>