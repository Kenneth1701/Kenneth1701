<!DOCTYPE html>
<html lang="en">
    <?php 
        include("header.inc"); 
        include("menu.inc");
    ?>
    <body> 
        <h1 id="quiz_results">Quiz Results</h1><hr>
        <?php
            if((isset($_POST["firstname"])) && (isset($_POST["lastname"])) && (isset($_POST["studentid"]))
                && (isset($_POST["question1"])) && (isset($_POST["question2"])) && (isset($_POST["question3"])) && (isset($_POST["question4"])) && (isset($_POST["question5"]))){
                $firstname = trim($_POST["firstname"]);
                $lastname = trim($_POST["lastname"]);
                $studentid = trim($_POST["studentid"]);
            }
            else{ //to bring back to quiz.php if we try to access this page directly
                header("location: quiz.php");
                exit();
            }
            $err_msg=""; //declaring err_msg

            //!first name
            if($firstname == ""){
                $err_msg .= "<p>Please enter first name.</p>";
            }else if(!preg_match("/^[a-zA-Z]+$/", $firstname)){
                $err_msg .= "<p>First name can only contain letters.</p>";
            }

            //!last name
            if($lastname == ""){
                $err_msg .= "<p>Please enter last name.</p>";
            }else if(!preg_match("/^[a-zA-Z]+$/", $lastname)){
                $err_msg .= "<p>Last name can only contain letters.</p>";
            }

            //!student ID
            /*if($studentid = ""){
                $err_msg .= "<p>Please enter a student ID.</p>";
            }else if(!preg_match("/^{7,10}+$/", $studentid)){ //?unsure
                $err_msg .= "<p>Student ID can only be 7-10 digits long.</p>";
            }*/
            $score = 0;
            //question 1
            if(isset($_POST["question1"]) == "answer1_q1")
            {
                $score += 3;
            }
            //question 2
            if(isset($_POST["question2"]))
            {
                if(isset($_POST["answer1_q2"])) //* answer 1
                {
                    $score = $score + 0.3;
                }
                if(isset($_POST["awnser3_q2"])) //* answer 3
                {
                    $score = $score + 0.3;
                }
                if(isset($_POST["awnser4_q2"])) //* answer 4
                {
                    $score = $score + 0.4;
                }
            }
            //question 3
            if(isset($_POST["question3"]))
            {
                if(isset($_POST["Karlheinz Brandenburg"]))
                {
                    $score = $score + 1;
                }
            }
            //question 4
            if(isset($_POST["question4"]))
            {
                if(isset($_POST["comment"]))
                {
                    if($_POST["comment"] == "Fraunhofer Society" || $_POST["comment"] == "fraunhofer society" || $_POST["comment"] == "Fraunhofer society")
                    {
                        $score = $score + 1;
                    }
                }
            }
            //*question 5
            if(isset($_POST["question5"]))
            {
                if(isset($_POST["quantity"]))
                {
                    if($_POST["quantity"] == 1990)
                    {
                        $score = $score + 1;
                    }
                }
            }

            /*$score = 0;
            //*question 1
            if(isset($_POST["question1"]))
            {
                if(isset($_POST["answer1_q1"])) //* answer 1
                {
                    $score += 1;
                }
            }
            //*question 2
            if(isset($_POST["question2"]))
            {
                if(isset($_POST["answer1_q2"])) //* answer 1
                {
                    $score += 0.3;
                }
                if(isset($_POST["awnser3_q2"])) //* answer 3
                {
                    $score += 0.3;
                }
                if(isset($_POST["awnser4_q2"])) //* answer 4
                {
                    $score += 0.4;
                }
            }
            //*question 3
            if(isset($_POST["question3"]))
            {
                if(isset($_POST["Karlheinz Brandenburg"]))
                {
                    $score = $score + 1;
                }
            }
            //*question 4
            if(isset($_POST["question4"]))
            {
                if(isset($_POST["comment"]))
                {
                    if($_POST["comment"] == "Fraunhofer Society" || $_POST["comment"] == "fraunhofer society" || $_POST["comment"] == "Fraunhofer society")
                    {
                        $score = $score + 1;
                    }
                }
            }   
            //*question 5
            if(isset($_POST["question5"]))
            {
                if(isset($_POST["quantity"]))
                {
                    if($_POST["quantity"] == 1990)
                    {
                        $score = $score + 1;
                    }
                }
            }*/

            if($err_msg != ""){
                echo $err_msg;
                exit();
            }

            //!login to the database if everything is valid
            $host = "feenix-mariadb.swin.edu.au";
            $user = "s105217834";
            $pwd = "240905";
            $sql_db = "s105217834_db";
            $conn = @mysqli_connect($host, $user, $pwd, $sql_db);

            if(!$conn){
                die("<p>Database connection failure</p>");
            }
            else{
                $query = "CREATE TABLE IF NOT EXISTS attempts (
                    attemptid INT AUTO_INCREMENT PRIMARY KEY,
                    firstname VARCHAR(30) NOT NULL,  
                    lastname VARCHAR(30) NOT NULL,
                    studentid INT NOT NULL,
                    attemptnum INT NOT NULL,
                    score FLOAT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
                $result =  @mysqli_query($conn, $query);
                if(!$result){
                    die("<p class=\"wrong\"> Something is wrong with $query.</p>");
                }
                else{
                    //TODO: ADD SCORE BEFORE TIMESTAMP
                    $attemptnum = 0;
                    $query = "SELECT attemptnum FROM attempts WHERE studentid = '$studentid'";
                    $checkid = @mysqli_query($conn, $query);
                    if($studentid){
                        $attemptnum += 1; //* for testing
                    }
                    if($attemptnum <= 1){
                        //$attemptnum += 1;
                        $update_query = "UPDATE attempts SET attemptnum = '$attemptnum' WHERE studentid = '$studentid'";
                        $check_attemptnum = @mysqli_query($conn, $update_query);
                        if($attemptnum){
                            echo "<br><a href='quiz.php' id='return_quiz'>Click here</a>";
                            echo "<p id='return'>to have another attempt at the quiz.</p>";
                        }
                        else{
                            echo "<p class=\"wrong\"> Something is wrong with $update_query.</p>";
                            exit();
                        }
                    //$attemptnum += 1;
                    }
                    else if($attemptnum >= 2){
                        echo "<br><p>You've ran out of attempts.</p>";
                        exit();
                    }
                    /*if($attemptnum == 1){
                        $attemptnum += 1;
                        $update_query = "UPDATE attempts SET attemptnum = '$attemptnum' WHERE studentid = '$studentid'";
                        $check_attemptnum = @mysqli_query($conn, $query);
                        if($attemptnum){
                            echo "<br><a href='quiz.php' id='return_quiz'>Click here</a>";
                            echo "<p id='return'>to have another attempt at the quiz.</p>";
                        }
                        else{
                            echo "<p class=\"wrong\"> Something is wrong with $update_query.</p>";
                            exit();
                        }
                    //$attemptnum += 1;
                    }
                    if($attemptnum >= 2){
                        echo "<br><p>You've ran out of attempts.</p>";
                        exit();
                    }*/
                    //$attemptnum += 1;
                    $insert_query = "INSERT INTO attempts (attemptid, firstname, lastname, studentid, attemptnum, score, timestamp)
                                                    VALUE (NULL, '$firstname', '$lastname', '$studentid', '$attemptnum', '$score', NULL)";
                    $insert_result  = @mysqli_query($conn, $insert_query);

                    if($insert_result){
                        echo "<p class='recorded'>Your attempt has been successfully recorded.</p>";
                        //*echo "<p>Your attempt has been successfully recorded. The attempt id is " .mysqli_insert_id($conn). ".</p>";
                    }
                    else{
                        echo "<p class='recorded'>Your attempt was recorded unsuccessfully.</p>";
                        exit();
                    }
                    //!to show the last inputted attempt
                    $query = "SELECT * FROM attempts ORDER BY attemptid DESC LIMIT 1";
                    //reference: https://www.youtube.com/watch?v=3MtrbX8LFTA
                    $show_result = @mysqli_query($conn, $query);
                    if(!$show_result){
                        echo "<p>Something is wrong with ", $show_result,"</p>";
                    }
                    /*if(!$row = mysqli_fetch_assoc($show_result)){
                        echo "<p>No details found.</p>";
                    }*/
                    else{ //TODO: ADD SCORE 
                        if(mysqli_num_rows($show_result) > 0){
                            echo "<table border=\"2\">\n";
                            echo "<tr>\n"
                            ."<th scope=\"col\">Attempt ID</th>\n"
                            ."<th scope=\"col\">Data and Time</th>\n"
                            ."<th scope=\"col\">Student ID</th>\n"
                            ."<th scope=\"col\">First Name</th>\n"
                            ."<th scope=\"col\">Last Name</th>\n"
                            ."<th scope=\"col\">Attempt Number</th>\n"
                            ."<th scope=\"col\">Score</th>\n"
                            ."</tr>";
                            while($row = mysqli_fetch_assoc($show_result)){
                                echo "<tr>\n";
                                echo "<td>",$row["attemptid"],"</td>\n";
                                echo "<td>",$row["timestamp"],"</td>\n";
                                echo "<td>",$row["studentid"],"</td>\n";
                                echo "<td>",$row["firstname"],"</td>\n";
                                echo "<td>",$row["lastname"],"</td>\n";
                                echo "<td>",$row["attemptnum"],"</td>\n";
                                echo "<td>",$row["score"],"</td>\n";
                                echo "</tr>\n";
                            }
                            echo "</table>\n";
                            mysqli_free_result($show_result);

                            /*if($attemptnum <= 1){
                                $attemptnum += 1;
                                $update_query = "UPDATE attempts SET attemptnum = '$attemptnum' WHERE studentid = '$studentid'";
                                $check_attemptnum = @mysqli_query($conn, $update_query);
                                if($attemptnum){
                                    echo "<br><a href='quiz.php' id='return_quiz'>Click here</a>";
                                    echo "<p id='return'>to have another attempt at the quiz.</p>";
                                }
                                else{
                                    echo "<p class=\"wrong\"> Something is wrong with $update_query.</p>";
                                    exit();
                                }
                            //$attemptnum += 1;
                            }
                            else if($attemptnum >= 2){
                                echo "<br><p>You've ran out of attempts.</p>";
                                exit();
                            }*/

//!------------------
                            //!check attempts
                            //$query = "UPDATE * FROM attempts ORDER BY attemptid DESC LIMIT 1";
                            //$query = "SELECT studentid FROM attempts WHERE attemptnum = 1";
                            /*if($attemptnum == 1){
                                $update_query = "UPDATE attempts SET attemptnum = 2 WHERE studentid = '$studentid'";
                                $check_attemptnum = @mysqli_query($conn, $query);
                                if($attemptnum){
                                    echo "<br><a href='quiz.php' id='return_quiz'>Click here</a>";
                                    echo "<p id='return'>to have another attempt at the quiz.</p>";
                                }
                                else{
                                    echo "<p class=\"wrong\"> Something is wrong with $update_query.</p>";
                                    exit();
                                }
                            //$attemptnum += 1;
                            }
                            else if($attemptnum >= 2){
                                echo "<br><p>You've ran out of attempts.</p>";
                                exit();
                            }*/
//!------------------
                        }
                        else{
                            echo "<p>No details found.</p>";
                        }
                        mysqli_close($conn);
                    }
                }
            }
        ?>
    </body>
</html>

<!--$score = 0;
            //*question 1
            if(isset($_POST["question1"])) //* answer 1
            {
                $score += 1;
            }
            //*question 2
            if(isset($_POST["question2"])) //* answer 1
            {
                $score += 0.3;
            }
            if(isset($_POST["question3"])) //* answer 3
            {
                $score += 0.3;
            }
            if(isset($_POST["question5"])) //* answer 4
            {
                $score += 0.4;
            }
            //*question 3
            if(isset($_POST["question3"]))
            {
                $score += 1;
            }
            //*question 4
            if(isset($_POST["question4"]))
            {
                $score += 1;
                if($_POST["comment"] == "Fraunhofer Society" || $_POST["comment"] == "fraunhofer society" || $_POST["comment"] == "Fraunhofer society")
                {
                    $score += 1;
                }
            }
            //*question 5
            if(isset($_POST["question5"]))
            {
                $score += 1;
                if($_POST["quantity"] == 1990)
                {
                    $score += 1;
                }
            }-->