<!DOCTYPE html>
<html lang="en">
    <?php include("header.inc"); ?>
    <body>
        <h1 id="quiz_results">Quiz Results</h1><hr>
        <?php //?display table for answers and add an option to redo
            /*if((!isset($_POST["firstname"])) && (!isset($_POST["lastname"])) && (!isset($_POST["studentid"]))){
                header
            }*/
            //!login to the database
            $host = "feenix-mariadb.swin.edu.au";
            $user = "s105217834";
            $pwd = "240905";
            $sql_db = "s105217834_db";
            $conn = mysqli_connect($host, $user, $pwd, $sql_db);

            if(!$conn){
                die("<p>Database connection failure</p>");
            }
            $query = "CREATE TABLE IF NOT EXISTS attempts (
                attemptid INT AUTO_INCREMENT PRIMARY KEY,
                firstname VARCHAR(30) NOT NULL,  
                lastname VARCHAR(30) NOT NULL,
                studentid INT NOT NULL,
                attemptnum INT NOT NULL,
                score FLOAT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )";
            $result =  mysqli_query($conn, $query);
            if(!$result){
                die("<p class=\"wrong\"> Something is wrong with $query");
            }
            else{
                if((isset($_POST["firstname"])) && (isset($_POST["lastname"])) && (isset($_POST["studentid"]))){
                    $make = trim($_POST["firstname"]);
                    $model = trim($_POST["lastname"]);
                    $price = trim($_POST["studentid"]);
                    //$yom = trim($_POST["yom"]);
                }
                else{
                    header("location: quiz.php");
                }
                $correctAnswers = ['Question1' => 'Correct', ]; //*sample
                //!stanitising data
                function sanitise_input($data){
                    $data = trim($data);
                    $data = stripslashes($data);
                    $data = htmlspecialchars($data);
                    return $data;
                }
                    //$attemptid = sanitise_input($firstname);
                $firstname = sanitise_input($firstname);
                $lastname = sanitise_input($lastname);
                $studentid = sanitise_input($studentid);
                    //$attemptnum = sanitise_input($attempnum);
                    //$score = sanitise_input($partySize);
                if($attempnum == 1){
                    echo "<p>Your first attempt has been recorded</p>";
                    echo "<a href='quiz.php'>Click here</a>";
                    echo "<p> to have another attempt at the quiz.</p>";
                }
            }
        ?>
    </body>
</html>
<!--$correctAnswers = ['Question1' => 'Correct', ]; //*sample
                    //!stanitising data
                    function sanitise_input($data){
                        $data = trim($data);
                        $data = stripslashes($data);
                        $data = htmlspecialchars($data);
                        return $data;
                    }
                        //$attemptid = sanitise_input($firstname);
                    $firstname = sanitise_input($firstname);
                    $lastname = sanitise_input($lastname);
                    $studentid = sanitise_input($studentid);
                        //$attemptnum = sanitise_input($attempnum);
                        //$score = sanitise_input($partySize);
                    if($attempnum == 1){
                        echo "<p>Your first attempt has been recorded</p>";
                        echo "<a href='quiz.php'>Click here</a>";
                        echo "<p> to have another attempt at the quiz.</p>";
                    }-->