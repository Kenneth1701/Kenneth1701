<!DOCTYPE html>
<html lang="en">
    <?php include("header.inc") ?> <!--MENTION GROUP MEMBERS' NAME IN INDIVIDUAL REPORT-->
<body>
    <?php include("menu.inc"); ?>
    <!--<form method="post" action="https://mercury.swin.edu.au/it000000/formtest.php">-->
    <form method="post" action="markquiz.php" novalidate="novalidate">
    <div class="head">
        <h2>MP3 Quiz</h2>
        <p>This quiz will help you to understand more about MP3</p>
    </div>
    <div id="id">
        <fieldset>
            <legend>Student's Information</legend>
            <div id="id_2">
            <p>
            <label for="studentid" class="questions">Student ID:</label><br>
            <input type="text" name="studentid" id="studentid" maxlength="10" size="20" pattern="\d{7,10}" title="Must be 7-10 digits" required>
            </p>
            <p>
                <label for="firstname">Given name:</label><br>
                <input type="text" name="firstname" id="given" maxlength="15" size="20" pattern="^[a-zA-Z\s]+$" required="required">
            </p>
            <p>
                <label for="lastname">Family name:</label><br>
                <input type="text" name="lastname" id="family" maxlength="15" size="20" pattern="^[a-zA-Z]+$" required="required">
            </p>
            </div>
        </fieldset>
    </div>   
    <div id="mcq">
        <fieldset>
        <legend>1: What is MP3? (1 mark)</legend>
        <ul>
            <li>
                <input type="radio" name="question1" id="answer1_q1" value="answer1_q1" required>
                <label for="answer1_q1">An audio format that retains high quality music</label>              
            </li><br>
            <li>
                <input type="radio" name="question1" id="answer2_q1" value="answer2_q1">
                <label for="answer2_q1">A format used to store video and audio</label>
            </li><br>
            <li>  
                <input type="radio" name="question1" id="answer3_q1" value="answer3_q1">
                <label for="answer3_q1">A format that retains high quality video</label>
            </li><br>
            <li>
                <input type="radio" name="question1" id="answer4_q1" value="answer4_q1">
                <label for="answer4_q1">My phone 3</label>
            </li><br>
        </ul>
        </fieldset>
    </div>
    <div id="choose">
        <fieldset>
        <legend>2: What is the key features of the MP3? (3 marks)</legend>
        <ul>
            <li>
                <input type="checkbox" name="question2" id="answer1_q2" value="answer1_q2"/>
                <label for="answer1_q2">Good audio quality for a great listening experience</label> <!--CORRECT-->             
            </li><br>
            <li>
                <input type="checkbox" name="question2" id="answer2_q2" value="answer2_q2"/>
                <label for="answer2_q2">Small size for easy storage and sending around</label> <!--CORRECT-->   
            </li><br>
            <li>  
                <input type="checkbox" name="question2" id="answer3_q2" value="answer3_q2"/>
                <label for="answer3_q2">To be able to store video digitally and require small storage</label> <!--CORRECT-->   
            </li><br>
            <li>
                <input type="checkbox" name="question2" id="answer4_q2" value="answer4_q2"/>
                <label for="answer4_q2">A good format for streaming due to small size and good quality</label> <!--CORRECT-->   
            </li><br>
        </ul>
        </fieldset>
    </div>
    <div id="selection">
        <fieldset>
            <legend>3: Who developed MP3? (1 mark)</legend>
            <select name="question3" required="required">
                <option value>Please Select</option>
                <option value="Karlheinz_Brandenburg">Karlheinz Brandenburg</option>
                <option value="Friedrich_Bergius">Friedrich Bergius</option>
                <option value="Nikola_Tesla">Nikola Tesla</option>
                <option value="Hermann_von_Helmholtz">Hermann von Helmholtz</option>
            </select>
        </fieldset>
    </div>
    
    <div id="input">
        <fieldset>
            <legend for="comment" class="questions">4: What group started and researched the MP3 in 1987? (1 mark)</legend>
            <textarea id="comment" name="question4" rows="1" cols="40" placeholder="Type your answer here..."></textarea>
        </fieldset> 
    </div>
    
    <div id="total">
        <fieldset>
            <legend class="questions">5: What exact year did MP3 start to gain traction? (1 mark)</legend>
            <div id="total_2">
            <label for="quantity">The exact year is:</label>
            <input type="number" id="quantity" name="question5" step="1" min="1980" max="2010" placeholder="0">
            </div>
        </fieldset>
    </div>
    
    <div id="submitbutton">
        <p>
            <input type="submit" value="SUBMIT">
            <input type="reset" value="RESET FORM">
        </p>
    </div>
    
</body>
<?php include("footer.inc"); ?> <!--Van Sung Tran-->
</html>