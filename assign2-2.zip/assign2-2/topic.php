<!DOCTYPE html>
<html lang="en">
    <?php include("header.inc"); ?>
    <body>
    <section>
        <?php include("menu.inc"); ?>
    </section> 
    <section id="topicnav">
        <aside>
            <a href="#content">Introduction and Key Features</a><br><br>
            <a href="#development">The Person Who Developed It</a><br><br>
            <a href="#management">Management of MP3</a><br><br>
            <a href="#growth">Growth of the MP3</a><br><br>
            <a href="#similarity">Similarity</a><br><br>
        </aside>
    </section>
    <div id="content">
        <section>
            <div class="introduction">
                <h1>Introduction</h1>
                <hr>
                <p>MP3 is an audio format that retains high quality music without having to take up too much space on devices. Main purpose of the MP3 is to be able to store audio digitally and require small storage.</p>
                <div id="keyfeature">
                    <h2>Key Features</h2>
                    <ul>
                        <ol type = "1">
                            <li>Good audio quality for a great listening experience</li>
                            <li>A good format for streaming due to small size and good quality</li>
                            <li>Small size for easy storage and sending around.</li>
                            <li>Has a big range of compatibility with many devices.</li>
                            <li>A method of compression that make the audio file small while keeping the quality of the music</li>
                        </ol>
                    </ul>
                </div>
            </div>
        </section>
        <section id="development">
            <div class = "developed">
                <h2>The person who developed it</h2><hr>
                <p>It was led by Karlheinz Brandenburg with the Fraunhofer Society and other scientists from different regions to develop it. In 1987 they began research on MP3. The main purpose of MP3 is to take advantage of the concept of auditory masking where there is limitation to human hearing. MP3 achieved this by providing high quality audio while retaining a small file size.</p>
                <figure>
                    <img src="images/Karlheinz_Brandenburg.jpg" alt="Karlheinz Brandenburg" width="331.5" height="421.5">
                    <figcaption>A photo of Karlheinz_Brandenburg</figcaption><br>
                </figure>
            </div>
        </section>
            <div id = "management">
         
            <section>
                <h2>Management of MP3</h2><hr>
                <ul>
                    <li>The research began in 1987 by Fraunhofer Institute in germany. The code name was EUREKA project EU147, DAB(Digital Audio Broadcasting). January 1998 MPEG(Moving Picture Expert Group) was established as a subcommittee known as ISO(International Standard Organization) and IEC(International Electrical Commission).</li>
                    <li>In 1989 Fraunhofer got the patent for MP3 in germany</li>
                    <li>In 1992 audio coding algorithms were integrated into MPEG-1 by Fraunhofer’s and Dieter Seitzer. The MPEG-1 standard was published in 1993.</li>
                    <li>A year later MPEG-2 was developed and published.</li>
                    <li>On 26th November 1996 the MP3 patent was issued.</li>
                    <li>September 1998 is when Fraunhofer started enforcing their patent right. All MP3 encoders and decoders must pay licensing fees however there is no licensing fee for using mp3 players. In later years the portable mp3 players were released to the public. There were no other update to the MP3 ever since</li>
                </ul> 
            </div> 
        </section>
                <div id = "growth">
                    <h1>Growth of the MP3</h1><hr>
                    <p>With the growing popularity of the internet alongside many artists starting to use MP3, it started to gain traction during mid-late 1990’s. Some of the main factors that help boost MP3 popularity would be the internet and MP3 players becoming a trend. On the point of the internet, with MP3 being so small it is easy for people to send each other MP3 files considering the internet back in the day being small and many personal computers having small storage spaces. Which makes MP3 a very convenient way to store audio files. Another factor add on would be the rising trend of using MP3 players. Before the MP3 was released to the public people would listen to music via vinyl record,Jukebox ,Cd player, Sony Walkman. However with the release of MP3, people were introduced to the ability to walk around and listen to music without having to carry something bulky nor do they have to sacrifice the quality of the music for convenience of carrying it around. This would help skyrocket the growth of MP3 players to a whole new level. When the ipod was first introduced it became a smash hit and set the path for MP3 players and skyrocketed the usage rate of MP3 players to a new height. However as technology develops, new technology starts coming out such as the smartphone which would later replace many people's MP3 player. Despite MP3 players being replaced left and right the usage of MP3 format still remains the same since many smartphones implemented an MP3 player in them. Within the current year the usage of MP3 has slowly decreased overtime due to new concepts like music streaming such as Spotify which use an Ogg Vorbis audio format. The usage of MP3 in the future may keep on decreasing however there would be a select few who would still use it. </p>
                        <div id = "the_table">
                            <table border="1">    
                                <tr>
                                    <th>Portable Media Player/MP3</th>
                                    <th>Audio sales</th>
                                </tr>
                                <tr>
                                    <td>2013</td>
                                    <td>$2.93 Billion</td>
                                </tr>
                                <tr>
                                    <td>2014</td>
                                    <td>$1.97 billions</td>
                                </tr>
                                <tr>
                                    <td>2015</td>
                                    <td>$1.02 billions</td>
                                </tr>
                                <tr>
                                    <td>2016</td>
                                    <td>$0.74 billions</td>
                                </tr>
                                <tr>
                                    <td>2017</td>
                                    <td>$0.73 billions</td>
                                </tr>
                                    <td>2018</td>
                                    <td>$0.77 billions</td>
                            </table>
                            <aside>
                                <p>This table does not count other smart devices such as laptop and smartphones that have a MP3 player inside of it</p>
                            </aside>
                </div>
                
        </section> 
    </div>
    <div id="similarity">
        <h1>Similarity</h1><hr>
        <p>One of the technologies that share common similarity with the MP3 would be the Flac format. They are both audio formats with the goal of providing the user with high quality audio. However both formats have different methods and have different visions for their format. A contrast between these two formats would be flac's main goal is to provide the highest audio quality with as much detail as possible to replicate the originality of how the artist intended which would increase the file size of the audio.In contrast to this MP3 goals is the devliever high quality audio too but would rather compress the file and make it smaller by sacrificing some quality.  As a result, an Mp3 would be easier for sharing files to friends and family or putting it on a portable device and listening while traveling. On the other hand Flac would provide a much better <experience class="x"></experience></p>
    </div>
    <div class="references">
        <h3>References: </h3>
        <a href="https://en.wikipedia.org/wiki/MP3">MP3</a><br>
        <a href="https://www.thoughtco.com/history-of-mp4-1992132">Technology</a><br>
        <a href="https://www.statista.com/chart/18209/mp3-player-and-headphone-sales-in-the-us/">Portable Audio Sale Are Shifting</a><br>
        <a href="https://www.off-the-beat.com/flac-vs-mp3/">FLAC vs MP3</a><br>
    </div>
    </body>
    <?php include("footer.inc"); ?> <!--Kenneth Grasiano-->
</footer> 
</html>