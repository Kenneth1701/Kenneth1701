<!DOCTYPE html>
<html lang="en">
<?php include("header.inc"); ?>
<body>
    <?php include("menu.inc"); ?>
    <section id="enhance_title">
        <h1>Enhancement Page</h1>
        <p>There are many ways you can improve the experience of the visitors of the website. Here are the things we did:</p>
    </section>
    <section class="enhance_block">
    <h2>The Burger Menu</h2><hr>
    <p class="enhance_paragraph">The menu goes beyond the basic requirement because it make the page much more responsive. It reacts to the size of the webpage itself. If the user were to shrink the page, the navigation bar would shrink into a 3 line, or what's called the 'burger menu' to try and fit with the size of the page.</p><br>
    <p>The CSS code that was used:</p>
    <p class="enhance_code_1">
        .toggle{<br>
            display: none;<br>
         }<br>
         .toggle:checked ~.ul li{<br>
            display: block;<br>
         }<br>
         .toggle_label{<br>
            margin-right: 20px;<br>
            display: block;<br>
         }<br>
         .toggle_label:hover{<br>
            cursor: pointer;<br>
         }<br>
         .toggle_label span,<br>
         .toggle_label span::before,<br>
         .toggle_label span::after{<br>
            display: block;<br>
            background: black;<br>
            height: 2px;<br>
            width: 2em;<br>
            border-radius: 2px;<br>
            position: relative;<br>
         }<br>
         .toggle_label span::before,<br>
         .toggle_label span::after{<br>
            content: '';<br>
            position: absolute;<br>
         }<br>
         .toggle_label span::before{<br>
            bottom: 7px;<br>
         }<br>
         .toggle_label span::after{<br>
            top: 7px;<br>
         }<br>
         .navbar {<br>
             padding: 0 10px;<br>
         }<br>
         .ul li {<br>
            display: none;<br>
             margin: 0 5px;<br>
         }<br>
    </p>
    <p>You can see how we implement this simply by resizing any page.</p><br>
    <p><strong>Reference:</strong> Create a responsive navigation nav with no JS! [online] Available at:</p>
    <a href="https://www.youtube.com/watch?v=8QKOaTYvYUA" class="enhance_link">Create a responsive navigation nav with no JS!</a>
    </section>

    <section class="enhance_stick">
        <h2>About Page's Side Menu</h2><hr>
        <p class="enhance_paragraph">This side menu in the about page implements the 'sticky' element in CSS in order for it to stick to the top of the page when you scroll down. This way, you're able to go to any part of the page where ever you're at when browsing the webpage.</p><br>
        <p>The CSS code that was used:</p>
        <p class="enhance_code">position: sticky;</p>
        <p>Location in which we applied this:</p>
        <a href="topic.php#topicnav" class="enhance_link">Link to the enhancement</a><br><br>
        <p><strong>Reference:</strong> How TO - Sticky Element. [online] Available at:</p>
        <a href="https://www.w3schools.com/howto/howto_css_sticky_element.asp" class="enhance_link">How TO - Sticky Element</a>
    </section>

    <section class="enhance_block">
        <h2>HTML 'iframe' Tag</h2><hr>
        <p class="enhance_paragraph">Along with having the link to the video in the homepage, you could also view the video via the in-built display in the webpage. Essentially having a YouTube page inside of the webpage.</p>        
        <p>The HTML code that was used:</p>
        <img src="images/iframe.png" alt="iframe_code" width="520" height="39">
        <p><u>Note:</u> The source file in this image hasn't been added yet as the video is needed to be added last.</p><br>
        <p>Location in which we applied this:</p>
        <a href="index.php#video" class="enhance_link">Link to the enhancement</a><br><br>
        <p><strong>Reference:</strong> HTML Iframe. [online] Available at:</p>
        <a href="https://www.w3schools.com/html/html_iframe.asp" class="enhance_link">HTML Iframes</a>
    </section>
    
    <section class="enhance_stick">
        <h2>HTML Target Attribute</h2><hr>
        <p class="enhance_paragraph">Along with being able to access another page in the same tab via the navigation menu, in the homepage, you're able to access the 'About', 'Quiz', and 'Enhancement' pages in another tab with just a click of a button.</p>
        <p>The HTML code that was used:</p>
        <img src="images/_blank.png" alt="_blank_code" width="406" height="16">
        <p>Location in which we applied this:</p>
        <a href="index.php#topic" class="enhance_link">Link to the enhancement</a><br><br>
        <p><strong>Reference:</strong> HTML target Attribute. [online] Available at:</p>
        <a href="https://www.w3schools.com/html/html_iframe.asp" class="enhance_link">HTML target Attribute</a>
    </section>

    <section class="enhance_block">
        <p><strong>Additional References:<strong></p>
        <a href="https://www.youtube.com/watch?v=SAx5bW_o4_E" class="enhance_link">How we linked to another element in another page.</a>
    </section>
</body>
<?php include("footer.inc"); ?> <!--Rothpitou Poeung-->
</html>